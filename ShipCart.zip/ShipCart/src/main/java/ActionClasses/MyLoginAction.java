package ActionClasses;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MyLoginAction extends MyAction{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		
		return null;
	}

}
